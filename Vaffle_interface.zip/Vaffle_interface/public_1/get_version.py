# -*- coding:UTF-8 -*-

#---------------获取version版本----------------------
class Version():

    def test_version(self):

        self.version ="4.0.6"

        return self.version