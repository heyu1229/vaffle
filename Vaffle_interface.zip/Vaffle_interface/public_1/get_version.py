# -*- coding:UTF-8 -*-

#---------------获取version版本----------------------
class Version():

    def test_version(self):

        self.version ="2.2.1"

        return self.version