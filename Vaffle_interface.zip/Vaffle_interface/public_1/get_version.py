# -*- coding:UTF-8 -*-

#---------------获取version版本----------------------
class Version():

    def test_version(self):

        self.version ="2.2.0"

        return self.version