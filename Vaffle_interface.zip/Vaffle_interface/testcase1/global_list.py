import os
path=os.getcwd()[:-9]
print(path)
# path = 'E:/python35/git/test_code/Vaffle_interface'
# path = '/usr/lib/python3/heaven_interface_vaffle2.0_auto2'