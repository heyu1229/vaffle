import os
path=os.getcwd()[:-9]
print(path)
# path = '/usr/lib/python3/heaven_interface_vaffle2.0_auto2'