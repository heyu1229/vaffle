# -*- coding:UTF-8 -*-
import unittest
import requests
import time,gc,sys

#------------------------用户个人中心---------------------------

from Vaffle_interface.public_1.func_requests import FuncRequests
from Vaffle_interface.public_1.get_url import Url

#---------------第三方登录接口----------------------
class Passport_Login(unittest.TestCase):

    def setUp(self):
        self.member_uuid = Url().test_user()
        self.requests = FuncRequests()

    #-----------------第三方facebook登录成功----------------------------------
    #-----------------facebook:411568645883504 twitter:861855853032357889  vk:427871220--------------------------
    def testcase_001(self):
        sheet_index = 2
        row = 2
        print("testcase_001第三方facebook登录成功：")
        member_id = "none"
        result=self.requests.interface_requests(member_id,sheet_index,row)

        self.assertEqual(10000, result["code"])
        print("code返回值：10000")



if __name__=="__main__":
    unittest.main()
